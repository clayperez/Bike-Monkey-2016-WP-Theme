<?php get_header(); ?>
<?php get_template_part('content', 'navbar'); ?>
<?php get_template_part('content', 'mainslider'); ?>

<?php get_template_part('content', 'sections'); ?>

<?php get_template_part('content', 'footer'); ?>
<?php get_footer(); ?>
