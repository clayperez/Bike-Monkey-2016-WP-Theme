      <a href="/" class="w-nav-brand brand-container">
        <img width="140" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/bmbwmic2016.png" class="header-logo">
      </a>
