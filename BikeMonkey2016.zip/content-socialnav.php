        <!-- BEGIN: STATIC SOCIAL ICONS -->
        <a href="http://www.facebook.com/bikemonkey" target="_blank" class="w-nav-link header-nav-link icon-nav-link fb"></a>
        <a href="http://www.twitter.com/bikemonkey" target="_blank" class="w-nav-link header-nav-link icon-nav-link tw"></a>
        <a href="http://www.instagram.com/bikemonkey" target="_blank" class="w-nav-link header-nav-link icon-nav-link ig"></a>
        <!-- END: STATIC SOCIAL ICONS -->
