  <div id="Footer" class="w-section footer">
    <div class="w-row footer-row">
      <div id="bmFooterColum1" class="w-col w-col-4">
        <div class="w-richtext">
          <h4>ABOUT BIKE MONKEY</h4>
          <p data-new-link="true">We are a professional events management and services company.</p>
        </div>
      </div>
      <div id="bmFooterColum2" class="w-col w-col-4">
        <div class="w-richtext">
          <h4>CONTACT INFO</h4>
          <p data-new-link="true">info@bikemonkey.net</p>
          <p data-new-link="true">PO Box 5318
            <br>Santa Rosa CA 95404</p>
          <p data-new-link="true">(707) 560-1122</p>
        </div>
      </div>
      <div id="bmFooterColum3" class="w-col w-col-4"></div>
    </div>
  </div>